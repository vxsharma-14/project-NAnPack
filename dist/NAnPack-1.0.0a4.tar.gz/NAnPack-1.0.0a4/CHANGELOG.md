# add version updates in this file.

### 1.0.0-alpha4
made changes to the modules- added/deleted//merged modules
added toutorials
added function documentations etc.
This is not an accurate update log because lot of changes were made in the overall structure of the package and since this is a pre-release version, not all changes are recorded.

### 1.0.0-alpha3
made changes to the setup.py file to correctly package the components.

### version 1.0.0-alpha2
1. setup.py file not correctly configured in the alpha1 version.
2. edited/changed documentations