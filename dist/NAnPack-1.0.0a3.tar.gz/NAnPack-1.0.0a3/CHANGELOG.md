# add version updates in this file.

## version 1.0.0-alpha3
made changes to the setup.py file to correctly package the components.

## version 1.0.0-alpha2
1. setup.py file not correctly configured in the alpha1 version.
2. edited/changed documentations