
'''
__init__ file'''

# napack Version
__version__ = "1.0.0"
