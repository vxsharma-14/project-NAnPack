def test_config():
    '''Test configuration.'''
    import numpy as np
    import nanpack.simset as sst

    
